import React, { useState } from 'react';
import './App.css';
import './NotificationCard.css';
import map from './map.png';
import info from './info.png';
import point from './point.png';

const App = () => {
  const [activeButton, setActiveButton] = useState(null);
  const [filterText, setFilterText] = useState('');

  const handleButtonClick = (index) => {
    setActiveButton(index);
  };

  const alert = {
    "2.27.2024": [
      {
        type: "alert",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "11:00",
        details: "[Алмата] Аэропорт камера на вход №1",
      },
      {
        type: "alert",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "13:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
      {
        type: "alert",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "9:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
    "2.16.2024": [
      {
        type: "alert",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "15:00",
        details: "[Алмата] Аэропорт камера на вход №1",
      },
    ],
    "2.12.2024": [
      {
        type: "alert",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
  };

  const warning = {
    "2.28.2024": [
      {
        type: "warning",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
    "2.27.2024": [
      {
        type: "warning",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
    "2.21.2024": [
      {
        type: "warning",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
  };

  const info = {
    "02.24.2024": [
      {
        type: "Авторизация",
        title: "СИЗ: Успешная Авторизация",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
    "02.25.2024": [
      {
        type: "warning",
        title: "СИЗ: ИНФО 1",
        time: "15:00",
        details: "[Алмата] Аэропорт камера на вход №1",
      },
    ],
    "4.02.2024": [
      {
        type: "warning",
        title: "СИЗ: Информация номер 2",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
    "3.09.2024": [
      {
        type: "warning",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "15:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
      {
        type: "alert",
        title: "СИЗ: ОТСУТСТВУЕТ КАСКА",
        time: "13:00",
        details: "[Астана] Аэропорт камера на вход №1",
      },
    ],
  };

  const filterNotifications = (notifications) => {
    return Object.keys(notifications).reduce((filtered, date) => {
      const filteredByDate = notifications[date].filter((notif) => 
        notif.title.toLowerCase().includes(filterText.toLowerCase()) || 
        notif.details.toLowerCase().includes(filterText.toLowerCase())
      );
      if (filteredByDate.length > 0) {
        filtered[date] = filteredByDate;
      }
      return filtered;
    }, {});
  };

  const filteredAlert = filterNotifications(alert);
  const filteredWarning = filterNotifications(warning);
  const filteredInfo = filterNotifications(info);

  return (
    <div className="app">
      <div className="filters">
        <input
          type="text" 
          placeholder="Поиск" 
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
        />
        <select className="type-event-select" img>
          <option>Тип события</option>
          <option>Все события</option>
          <option>Организация-объекты</option>
          <option>Пользователи-роли</option>
          <option>Авторизация</option>
          <option>Работа с камерами</option>
          <option>Управление ПТЗ</option>
          <option>Действия системы</option>
          <option>Правила реагирования</option>
          <option>Аналитика</option>
          <option>Отчет</option>
        </select>
        <select>
          <option>Тип лога</option>
          <option>Успешная авторизация</option>
          <option>Ошибка авторизация</option>
          <option>Восстановление пароля</option>
          <option>Смена пароля после восстановления</option>
          <option>Смена пароля</option>
          <option>Временная блокировка</option>
          <option>Блокировка при многократных ошибках входа</option>
          <option>Блокировка при другом отсутствии</option>
          <option>Отправка письма о восстановлениии пароля</option>
        </select>
        <input type="date"/>
        <div className="contime">
          {["3 часа", "сегодня", "вчера"].map((label, index) => (
            <button
              key={index}
              className={`timebutton ${activeButton === index ? "active" : ""}`}
              onClick={() => handleButtonClick(index)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="columns">
        <Column headerClass="alert" title="Тревоги" notifications={filteredAlert} />
        <Column headerClass="warning" title="Предупреждения" notifications={filteredWarning} />
        <Column headerClass="info" title="Информация" notifications={filteredInfo} />
      </div>
    </div>
  );
};

const Column = ({ headerClass, title, notifications }) => {
  const notificationCount = Object.values(notifications).reduce(
    (total, dayNotifications) => total + dayNotifications.length,
    0
  );

  const sortedNotifications = Object.keys(notifications).sort(
    (a, b) => new Date(b) - new Date(a)
  );

  return (
    <div className="column-container">
      <div className={`header ${headerClass}`}>
        <div className="header-content">
          <div className={`notification-count ${headerClass}-count`}>
            {notificationCount}
          </div>
          <p className="header-title">{title}</p>
        </div>
      </div>
      <div className="notifications">
        {sortedNotifications.map((date, idx) => {
          const notifDate = new Date(date);
          const formattedDate = `${notifDate.getDate()}.${notifDate.getMonth() + 1}.${notifDate.getFullYear()}`;

          return (
            <div key={date}>
              {idx === 0 ||
              new Date(sortedNotifications[idx - 1]).getDate() !==
                notifDate.getDate() ? (
                <div className="date">{formattedDate}</div>
              ) : null}
              {notifications[date]
                .sort(
                  (a, b) =>
                    new Date(`1970-01-01T${b.time}:00Z`) - 
                    new Date(`1970-01-01T${a.time}:00Z`)
                )
                .map((notif, index) => (
                  <NotificationCard
                    key={index}
                    type={notif.type}
                    title={notif.title}
                    time={notif.time}
                    details={notif.details}
                  />
                ))}
            </div>
          );
        })}
      </div>
    </div>
  );
};

const NotificationCard = ({ type, title, time, details }) => {
  const [menuVisible, setMenuVisible] = useState(false);
  const [isRead, setIsRead] = useState(false); // Состояние для отметки "прочитано"

  const toggleMenu = () => {
    setMenuVisible((prevVisible) => !prevVisible);
  };

  const closeMenu = (e) => {
    if (!e.target.closest(".menu")) {
      setMenuVisible(false);
    }
  };

  React.useEffect(() => {
    document.addEventListener("click", closeMenu);
    return () => {
      document.removeEventListener("click", closeMenu);
    };
  }, []);

  const toggleReadStatus = () => {
    setIsRead((prevRead) => !prevRead); // Переключаем состояние "прочитано"
  };

  return (
    <div
      className={`notification-card ${type} ${isRead ? "read" : ""}`}
    >
      <div className="card-header">
        <button className="info">
          <img src={info} alt="Информация" />
          <span>сиз</span>
        </button>
        <button className="map">
          <img src={map} alt="Карта" />
          <span className="maptool">Перейти в ГИС</span>
        </button>
        <div className="time">{time}</div>
        <div className="read">
          <img 
            src={point} 
            alt={isRead ? "Сделать непрочитанным" : "Отметить как прочитанное"} 
            onClick={toggleReadStatus} 
            style={{ cursor: "pointer" }} 
          />
        </div>
        <div className="menu">
          <button className="menu-button" onClick={toggleMenu}>•••</button>
          {menuVisible && (
            <div className="dropdown-menu">
              <ul>
                <li>Информация о событии</li>
                <li>Отобразить на карте</li>
                <li>Отметить как прочитанное</li>
              </ul>
            </div>
          )}
        </div>
      </div>
      <div className="card-body">
        <h4 className="title">{title}</h4>
        <p className="details">{details}</p>
      </div>
    </div>
  );
};

export default App;