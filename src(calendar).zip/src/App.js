import React from "react";
import CalendarDropdown from "./components/CalendarRange";

function App() {
  return (
    <div className="App">
      <CalendarDropdown />
    </div>
  );
}

export default App;