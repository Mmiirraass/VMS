import React, { useState } from "react";
import "./Calendar.css";
import colon from "./colon.png";
import left from "./left.png";
import right from "./right.png";

const CalendarRange = () => {
  const [leftDate, setLeftDate] = useState(null);
  const [rightDate, setRightDate] = useState(null);
  const [startTime, setStartTime] = useState({ hours: "00", minutes: "00" });
  const [endTime, setEndTime] = useState({ hours: "23", minutes: "59" });
  const [leftMonth, setLeftMonth] = useState(new Date());
  const [rightMonth, setRightMonth] = useState(
    new Date(new Date().setMonth(new Date().getMonth() + 1))
  );

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const days = [];
    const startDay = firstDay.getDay();

    for (let i = 0; i < (startDay === 0 ? 6 : startDay - 1); i++) {
      days.push(null);
    }

    while (firstDay.getMonth() === month) {
      days.push(new Date(firstDay));
      firstDay.setDate(firstDay.getDate() + 1);
    }

    return days;
  };

  const getDaysOfWeek = () => ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

  const handleDateSelection = (date, isLeft) => {
    if (isLeft) {
      setLeftDate(date);
      if (rightDate && date > rightDate) setRightDate(null);
    } else {
      setRightDate(date);
    }
  };

  const handleCancel = () => {
    setLeftDate(null);
    setRightDate(null);
    setStartTime({ hours: "00", minutes: "00" });
    setEndTime({ hours: "23", minutes: "59" });
  };

  const handleApply = () => {
    console.log("Диапазон дат:", leftDate, rightDate);
    console.log("Время:", startTime, endTime);
  };

  const renderDays = (month, selectedDate, isLeft) =>
    getDaysInMonth(month).map((day, idx) => (
      <div
        className={`day-cell ${
          (day &&
            ((isLeft && day.toDateString() === leftDate?.toDateString()) ||
              (!isLeft && day.toDateString() === rightDate?.toDateString()))) &&
          "selected"
        } ${
          day &&
          leftDate &&
          rightDate &&
          day > leftDate &&
          day < rightDate &&
          "in-range"
        }`}
        key={idx}
        onClick={() => day && handleDateSelection(day, isLeft)}
        style={{
          visibility: day ? "visible" : "hidden",
        }}
      >
        {day ? day.getDate() : ""}
      </div>
    ));  

  return (
    <div className="calendar-range">
      <div className="calendar-header">
        <div className="calendar-container">
          <div className="calendar-title">
            <span className="monthname">
              {leftMonth.toLocaleString("default", { month: "long" })}{" "}
              {leftMonth.getFullYear()}
            </span>
            <div className="changemonth">
              <button
                className="arrow-button"
                onClick={() =>
                  setLeftMonth((prev) => {
                    const newDate = new Date(prev);
                    newDate.setMonth(prev.getMonth() - 1);
                    return newDate;
                  })
                }
              >
                <img src={left} className="arrow-image" />
              </button>
              <button
                className="arrow-button"
                onClick={() =>
                  setLeftMonth((prev) => {
                    const newDate = new Date(prev);
                    newDate.setMonth(prev.getMonth() + 1);
                    return newDate;
                  })
                }
              >
                <img src={right} className="arrow-image" />
              </button>
            </div>
          </div>
          <div className="calendar-days-header">
            {getDaysOfWeek().map((day, idx) => (
              <div className="day-header" key={idx}>
                {day}
              </div>
            ))}
          </div>
          <div className="calendar-content">
            {renderDays(leftMonth, leftDate, true)}
          </div>
        </div>

        <div className="calendar-container">
          <div className="calendar-title">
            <span className="monthname">
              {rightMonth.toLocaleString("default", { month: "long" })}{" "}
              {rightMonth.getFullYear()}
            </span>
            <div className="changemonth">
              <button
                className="arrow-button"
                onClick={() =>
                  setRightMonth((prev) => {
                    const newDate = new Date(prev);
                    newDate.setMonth(prev.getMonth() - 1);
                    return newDate;
                  })
                }
              >
                <img src={left} className="arrow-image" />
              </button>
              <button
                className="arrow-button"
                onClick={() =>
                  setRightMonth((prev) => {
                    const newDate = new Date(prev);
                    newDate.setMonth(prev.getMonth() + 1);
                    return newDate;
                  })
                }
              >
                <img src={right} alt="Right arrow" className="arrow-image" />
              </button>
            </div>
          </div>
          <div className="calendar-days-header">
            {getDaysOfWeek().map((day, idx) => (
              <div className="day-header" key={idx}>
                {day}
              </div>
            ))}
          </div>
          <div className="calendar-content">
            {renderDays(rightMonth, rightDate, false)}
          </div>
        </div>
      </div>

      <div className="time-select">
        <div className="time-input">
          <label htmlFor="start-time-hours">Выберите время</label>
          <div className="time-fields">
            <div className="time-field">
              <input
                id="end-time-hours"
                type="number"
                value={endTime.hours}
                onChange={(e) =>
                  setEndTime((prev) => ({ ...prev, hours: e.target.value }))
                }
                min="0"
                max="23"
              />
              <div className="time-span">
                <span>Часов</span>
              </div>
            </div>
            <img src={colon}></img>
            <div className="time-field">
              <input
                id="end-time-minutes"
                type="number"
                value={endTime.minutes}
                onChange={(e) =>
                  setEndTime((prev) => ({ ...prev, minutes: e.target.value }))
                }
                min="0"
                max="59"
              />
              <div className="time-span">
                <span>Минут</span>
              </div>
            </div>
          </div>
        </div>
        <div className="time-input">
          <label htmlFor="end-time-hours">Выберите время</label>
          <div className="time-fields">
            <div className="time-field">
              <input
                id="end-time-hours"
                type="number"
                value={endTime.hours}
                onChange={(e) =>
                  setEndTime((prev) => ({ ...prev, hours: e.target.value }))
                }
                min="0"
                max="23"
              />
              <div className="time-span">
                <span>Часов</span>
              </div>
            </div>
            <img src={colon}></img>
            <div className="time-field">
              <input
                id="end-time-minutes"
                type="number"
                value={endTime.minutes}
                onChange={(e) =>
                  setEndTime((prev) => ({ ...prev, minutes: e.target.value }))
                }
                min="0"
                max="59"
              />
              <div className="time-span">
                <span>Минут</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="calendar-footer">
        <button className="cancel-button" onClick={handleCancel}>
          ОТМЕНА
        </button>
        <button className="apply-button" onClick={handleApply}>
          УСТАНОВИТЬ
        </button>
      </div>
    </div>
  );
};

export default CalendarRange;